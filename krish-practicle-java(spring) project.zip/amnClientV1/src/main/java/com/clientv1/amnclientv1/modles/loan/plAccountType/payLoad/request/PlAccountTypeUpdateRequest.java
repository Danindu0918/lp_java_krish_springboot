package com.clientv1.amnclientv1.modles.loan.plAccountType.payLoad.request;

public class PlAccountTypeUpdateRequest {
}
