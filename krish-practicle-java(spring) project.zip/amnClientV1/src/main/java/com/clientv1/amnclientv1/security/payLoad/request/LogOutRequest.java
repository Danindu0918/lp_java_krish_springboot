package com.clientv1.amnclientv1.security.payLoad.request;

public class LogOutRequest {

    private Long userId;

    public Long getUserId() {
        return this.userId;
    }
}
