package com.clientv1.amnclientv1.modles.loan.repository;

import com.clientv1.amnclientv1.modles.loan.models.PlPolicyCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlPolicyCategoryRepository extends JpaRepository<PlPolicyCategory, Long> {
}
