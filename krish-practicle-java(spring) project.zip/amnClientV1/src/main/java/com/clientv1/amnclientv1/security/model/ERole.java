package com.clientv1.amnclientv1.security.model;

public class ERole {

//    ROLE_USER,
//    ROLE_MODERATOR,
//    ROLE_ADMIN
}
