package com.clientv1.amnclientv1.modles.loan.status;

public enum ELoanStatus {

    APPLICATION,
    APPRAISED,
    APPROVED,
    DISBURSED,
    ACTIVE,
    CLOSE
}
