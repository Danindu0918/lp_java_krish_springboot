package com.clientv1.amnclientv1.modles.loan.repository;

import com.clientv1.amnclientv1.modles.loan.models.GINotePolicy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GiNotePolicyRepository extends JpaRepository<GINotePolicy, Long> {
}
