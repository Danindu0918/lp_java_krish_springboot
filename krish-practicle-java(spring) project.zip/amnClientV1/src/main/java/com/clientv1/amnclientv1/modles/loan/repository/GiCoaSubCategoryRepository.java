package com.clientv1.amnclientv1.modles.loan.repository;

import com.clientv1.amnclientv1.modles.loan.models.GICoaSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GiCoaSubCategoryRepository extends JpaRepository<GICoaSubCategory, Long> {
}
