package com.clientv1.amnclientv1.modles.client.attachment;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AttachmentRepository extends JpaRepository<AttachmentDTO, Long> {
}
