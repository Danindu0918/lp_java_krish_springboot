package com.clientv1.amnclientv1.modles.loan.plAccountType.payLoad.responsed;

public class PlAccountTypeResponsed {
}
