package com.clientv1.amnclientv1.modles.loan.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface PlLoanInformationRepository {
}
