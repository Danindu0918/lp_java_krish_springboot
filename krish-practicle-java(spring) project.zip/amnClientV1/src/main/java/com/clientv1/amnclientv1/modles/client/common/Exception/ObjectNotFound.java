package com.clientv1.amnclientv1.modles.client.common.Exception;

public class ObjectNotFound extends RuntimeException{

    public ObjectNotFound(String message){
        super(message);
    }
}
