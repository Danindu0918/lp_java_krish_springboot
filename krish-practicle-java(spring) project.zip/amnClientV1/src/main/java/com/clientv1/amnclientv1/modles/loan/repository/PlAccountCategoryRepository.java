package com.clientv1.amnclientv1.modles.loan.repository;

import com.clientv1.amnclientv1.modles.loan.models.PlAccountCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlAccountCategoryRepository extends JpaRepository<PlAccountCategory, Long> {
}
