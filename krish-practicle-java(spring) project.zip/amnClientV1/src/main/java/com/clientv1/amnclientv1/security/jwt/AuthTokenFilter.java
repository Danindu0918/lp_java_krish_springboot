package com.clientv1.amnclientv1.security.jwt;

public class AuthTokenFilter {
}
