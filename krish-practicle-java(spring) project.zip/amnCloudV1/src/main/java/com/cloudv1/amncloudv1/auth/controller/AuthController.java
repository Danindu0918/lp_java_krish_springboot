package com.cloudv1.amncloudv1.auth.controller;

import com.clientv1.amnclientv1.security.payLoad.request.LogOutRequest;
import com.clientv1.amnclientv1.security.payLoad.request.LoginRequest;
import com.clientv1.amnclientv1.security.payLoad.request.TokenRefreshRequest;
import com.cloudv1.amncloudv1.auth.service.AuthService;
import com.cloudv1.amncloudv1.auth.service.SingupRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v2/auth")
@AllArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/signIn")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        return ResponseEntity.ok(authService.authenticateUser(loginRequest));
    }

    @PostMapping("/signUp")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SingupRequest signUpRequest) {
        return authService.registerUser(signUpRequest);
    }

    @PostMapping("/refreshToken")
    public ResponseEntity<?> refreshToken(@Valid @RequestBody TokenRefreshRequest request) {
        return authService.refreshToken(request);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logoutUser(@Valid @RequestBody LogOutRequest logOutRequest) {
        return authService.logoutUser(logOutRequest);
    }
}
