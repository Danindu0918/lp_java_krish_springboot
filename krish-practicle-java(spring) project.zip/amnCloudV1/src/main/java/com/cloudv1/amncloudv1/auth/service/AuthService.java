package com.cloudv1.amncloudv1.auth.service;

import com.clientv1.amnclientv1.security.exception.TokenRefreshException;
import com.clientv1.amnclientv1.security.model.RefreshToken;
import com.clientv1.amnclientv1.security.payLoad.request.LogOutRequest;
import com.clientv1.amnclientv1.security.payLoad.request.LoginRequest;
import com.clientv1.amnclientv1.security.payLoad.request.TokenRefreshRequest;
import com.clientv1.amnclientv1.security.payLoad.response.JwtResponse;
import com.clientv1.amnclientv1.security.payLoad.response.MessageResponse;
import com.clientv1.amnclientv1.security.payLoad.response.TokenRefreshResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.validation.Valid;

@Service
@AllArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder encoder;
    private final JwtUtils jwtUtils;
    private final RefreshTokenService refreshTokenService;

    public JwtResponse authenticateUser(LoginRequest loginRequest) {

        return null;

    }

    public ResponseEntity<MessageResponse> registerUser(@Valid SingupRequest signUpRequest) {

        return null;
    }

    public ResponseEntity<TokenRefreshResponse> refreshToken(TokenRefreshRequest request) {
        String requestRefreshToken = request.getRefreshToken();

        return refreshTokenService.findByToken(requestRefreshToken)
                .map(refreshTokenService::verifyExpiration)
                .map(RefreshToken::getUser)
                .map(user -> {
                    String token = jwtUtils.generateTokenFromUsername(user.getUsername());
                    return ResponseEntity.ok(new TokenRefreshResponse(token, requestRefreshToken));
                })
                .orElseThrow(() -> new TokenRefreshException(requestRefreshToken,
                        "Refresh token is not in database!"));
    }

    public ResponseEntity<MessageResponse> logoutUser(LogOutRequest logOutRequest) {
        refreshTokenService.deleteByUserId(logOutRequest.getUserId());
        return ResponseEntity.ok(new MessageResponse("Log out successful!"));
    }
}
