package com.cloudv1.amncloudv1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmnCloudV1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
