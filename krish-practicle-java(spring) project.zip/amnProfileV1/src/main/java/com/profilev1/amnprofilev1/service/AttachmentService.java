package com.profilev1.amnprofilev1.service;


public interface AttachmentService {

 AttachmentDTO save (AttachmentDTO attachmentDTO);
}
