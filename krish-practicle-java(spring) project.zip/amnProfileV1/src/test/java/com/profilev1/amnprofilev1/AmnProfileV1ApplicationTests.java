package com.profilev1.amnprofilev1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmnProfileV1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
