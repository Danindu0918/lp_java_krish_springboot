package com.example.pos_servlet.controller;

public class CustomerController {
}
